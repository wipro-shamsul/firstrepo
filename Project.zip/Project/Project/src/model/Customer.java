package model;

import java.util.ArrayList;

import interfaces.ICustomer;

public class Customer implements ICustomer{
	
	private int customerID;
	private String[] customerName;
	private String[] customerAddress;
	private String postCode;
	private String telephoneNum;
	private String city;
	private ArrayList<Transaction> transactionsList;
	
	public Customer() {}
	
	public Customer(String customerFName, String customerLName, String custAddrLine1, String custAddrLine2, String city, String postCode, String thelephone) {
		this.customerName = new String[2];
		this.customerName[0] = customerFName;
		this.customerName[1] = customerLName;
		this.customerAddress = new String[2];
		customerAddress[0] = custAddrLine1;
		customerAddress[1] = custAddrLine2;
		this.city = city;
		this.postCode = postCode;
		this.telephoneNum = thelephone;
	}
	
	public void setCustFirstName(String name1) {
		customerName[0] = name1;
	}

	public void setCustLastName(String name2) {
		customerName[1] = name2;
	}
	
	public void setCustomerName(String name1, String name2) {
		customerName[0] = name1;
		customerName[1] = name2;
	}
	
	public void setCustAddLine1(String address1) {
		customerAddress[0] = address1;
	}

	public void setCustAddLine2(String address2) {
		customerAddress[1] = address2;
	}
	
	public void setCity(String city) {
		this.city = city;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	
	public void setCustomerAddress(String address1, String address2) {
		customerAddress[0] = address1;
		customerAddress[1] = address2;
	}
	
	public void setPhoneNumber(String phoneNum) {
		this.telephoneNum = phoneNum;
		
	}
	
	public int getCustomerID() {
		return customerID;
	}

	public String getCustFirsName() {
		return customerName[0];
	}

	public String getCustLastName() {
		return customerName[1];
	}
	
	public String getCustomerName() {
		return customerName[0] + " " + customerName[1];
	}
	
	public String getAddresLineOne() {
		return customerAddress[0];
	}

	public String getAddresLineTwo() {
		return customerAddress[1];
	}
	
	public String getCity() {
		return city;
	}

	public String getPostCode() {
		return postCode;
	}
	
	public String getCustomerAddress() {
		return customerAddress[0] + " " + customerAddress[1];
	}

	public String getPhoneNum() {
		return telephoneNum;
	}
}
