package model;

public class Transaction {
	
	private Product product;
	private int itemQuantity;
	private int custID;
	
	public Transaction(Product product) {
		setInitialInputQuantity(product);
	}
	
	private void setInitialInputQuantity(Product product) {
		if(product != null) {
			this.product = product;
			this.itemQuantity = 1;
		}
		else {
			System.out.println("There cannot be a transaction without a product!");
		}
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}
	
	public void setQantity(int quantity) {
		this.itemQuantity = quantity;
	}
	
	public void setCustomerId(int custID) {
		this.custID = custID;
	}
	
	public Product getProduct() {
		return product;
	}
	
	public int getQuantity() {
		return itemQuantity;
	}
	
	public int getCustId() {
		return custID;
	}
}
