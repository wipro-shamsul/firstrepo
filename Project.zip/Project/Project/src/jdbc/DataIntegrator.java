package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Customer;

public class DataIntegrator {
	
    Connection con = null;
	
	public  Connection connect()
	{
		String url="jdbc:oracle:thin:@10.173.108.152:1522:orcl";		
		String uname="scott";
		String pwd = "tiger";

		
		try {
			con = DriverManager.getConnection(url,uname,pwd);
			System.out.println("Connected");
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
	public void close()
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/*
	 * PRODUCT CRUD
	*/
	
	public void insertProduct(ArrayList a)
	{
		String sql = "INSERT INTO Product (Name, Id, buyAt, sellAt, Quantity) VALUES (?, ?, ?, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setString(1, (String) a.get(0));
			statement.setInt(2, (int)  a.get(1));
			statement.setDouble(3, (double) a.get(2));
			statement.setDouble(4, (double) a.get(3));
			statement.setInt(5, (int) a.get(4));
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Product inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	public <E> void  updateProduct(int id, int selection, E x){
		
		String [] fields = {"Name", "buyAt", "sellAt", "Quantity"};
		
		String sql = "UPDATE Product SET "+ fields[selection]+"=? WHERE Id=?";

		
		PreparedStatement statement= null;
		try {
			statement = con.prepareStatement(sql);
			
			if(selection == 0){
				statement.setString(1, (String) x);
			}
			else if(selection == 1){
				statement.setDouble(1, (double) x);
			}
			else if(selection == 2){
				statement.setDouble(1, (double) x);
			}
			else if(selection == 3){
				statement.setInt(1, (int) x);
			}
			
			statement.setInt(2, id);
			
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Product updated successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e1)
		{
			System.out.println("Error updating");
		}
	}

	public void deleteProduct(int id){
		String sql = "DELETE FROM Product WHERE Id=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Product deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * CUSTOMER CRUD
	*/
	public void insertCustomer(Customer a)
	{
		String sql = "INSERT INTO Customers (cID, firstName, lastName, addressLine1, addressLine2, City, postcode, contactTelephone) VALUES (seq_customer.nextval, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setString(1, (String)  a.getCustFirsName()); //First name
			statement.setString(2, (String) a.getCustLastName()); //Last name
			statement.setString(3, (String) a.getAddresLineOne()); //Address line 1
			statement.setString(4, (String) a.getAddresLineTwo()); //Address line 2
			statement.setString(5, (String) a.getCity()); //City
			statement.setString(6, (String) a.getPostCode()); // Post code
			statement.setString(7, (String) a.getPhoneNum()); //Telephone
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Customer inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void updateCustomer(int id, String name, double buyA, double sellA, int quant){
		String sql = "UPDATE Product SET Name=?, buyAt=?, sellAt=?, quantity=?  WHERE Id=?";
		
		PreparedStatement statement= null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setString(1, name);
			statement.setDouble(2, buyA);
			statement.setDouble(3, sellA);
			statement.setInt(4, quant);
			statement.setInt(5, id);
			
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Product updated successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteCustomer(int id){
		String sql = "DELETE FROM Customer WHERE CustomerId=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Customer deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * TRANSACTION CRUD
	*/	
	
	public void insertTransaction(ArrayList a)
	{
		String sql = "INSERT INTO Transaction (ProductId, ItemQuantity, CustomerID, TransID) VALUES (?, ?, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setInt(1, (int) a.get(0)); //Product ID
			statement.setInt(2, (int) a.get(1)); //Item Quantity
			statement.setInt(3, (int) a.get(2)); //Customer ID
			statement.setInt(4, (int) a.get(3)); //Transaction ID
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Transaction inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void deleteTransaction(int id){
		String sql = "DELETE FROM Transaction WHERE TransactionId=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Transaction deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * SELECT ALL METHOD FOR ALL TABLES
	*/
	public ResultSet select(String table)
	{
		String sql = "SELECT * FROM "+ table;
				
		Statement statement;
		ResultSet result= null;
		
		try {
			statement = con.createStatement();
			result = statement.executeQuery(sql);			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}

}
