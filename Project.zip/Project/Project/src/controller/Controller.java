package controller;

import jdbc.DataIntegrator;

import java.sql.Connection;
import java.util.ArrayList;

import model.Customer;
import model.Transaction;

public class Controller {
	
	private ArrayList<Transaction> transactions;
	private Customer customer;
	DataIntegrator db;
	
	public Controller() {
		transactions = new ArrayList<Transaction>();
		
		db = new DataIntegrator();
		db.connect();
				
	}
	
	public void createNewUser(ArrayList<String> userData) {
		System.out.println("From controller " + userData.toString());
		customer = new Customer(userData.get(0), userData.get(1),userData.get(2), userData.get(3), userData.get(4), userData.get(5), userData.get(6));
		
		db.insertCustomer(customer);
		
	}
	
	public void modifyUserData(String userId, int dataColumn, String newValue) {
		System.out.println("From controller modifying user: " + userId +";column: " + ";new value: " + newValue );
	}
	
	public void deleteCustomer(String userId) {
		System.out.println("From controller deleting user: " + userId);
	}
	
	public void printUserData() {
		//get all the user data from the database!
	}
	
	public void createProduct(ArrayList<String> productData) {
		System.out.println(productData.toString());
	}
	
	public void modifyProduct(String prodId, int dataColumn, String newValue) {
		System.out.println("From controller modifying product: " + prodId +";column: " + ";new value: " + newValue );
	}
	
	public void deleteProduct(String productId) {
		System.out.println("From controller deleting product: " + productId);
	}
	
	public void printProductData() {
		//get all the product data from the database!
	}
	
	public void addANewTransaction(String prodId, String quantity) {
		System.out.println("From Controller new transaction with prodID:" + prodId + " quantity: " + quantity);
	}
	
	public void modifyTransaction(String prodId, String newValue) {
		System.out.println("From Controller modified transaction with prodID:" + prodId + "; new value:" + newValue);
	}
	
	public void deleteTransaction(String prodId) {
		System.out.println("From controller deteled transaction is" + prodId);
	}
	
	public void executeTransaction() {
		//assign to user.
	}
	
	public void assignTranstoCustomer(String custId) {
		//assign trans to customer
	}
}
