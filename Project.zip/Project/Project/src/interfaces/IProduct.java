package interfaces;

public interface IProduct {
	
	public void setName(String prodName);
	
	public void setBuyAt(double buyPrice);
	
	public void setSellAt(double sellPrice);
	
	public void setQuantity(int prodQuantity);
	
	public int getProductId();
	
	public String getProductName();
	
	public double getBuyPrice();
	
	public double getSellPrice();
	
	public int getQuantity();
}
