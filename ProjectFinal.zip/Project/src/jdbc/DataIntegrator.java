package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Customer;
import model.Product;
import model.Transaction;

public class DataIntegrator {
	
    Connection con = null;
	
	public  Connection connect()
	{
		String url="jdbc:oracle:thin:@10.173.108.152:1522:orcl";		
		String uname="scott";
		String pwd = "tiger";

		
		try {
			con = DriverManager.getConnection(url,uname,pwd);
			System.out.println("Connected");
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
	public void close()
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/*
	 * PRODUCT CRUD
	*/
	
	public void insertProduct(Product a)
	{
		String sql = "INSERT INTO Products (pID, name, buyAt, sellAt, quantity) VALUES (seq_product.nextval, ?, ?, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setString(1, (String) a.getProductName()); //Name
			statement.setDouble(2, (double)  a.getBuyPrice()); //buyAt
			statement.setDouble(3, (double) a.getSellPrice()); //sellAt
			statement.setInt(4, (int) a.getQuantity()); //quantity
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Product inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	public <E> void  updateProduct(int id, int selection, E x){
		
		String [] fields = {"Name", "buyAt", "sellAt", "Quantity"};
		
		String sql = "UPDATE Products SET "+ fields[selection-1]+"=? WHERE pID=?";

		System.out.println("THIS IS IT " + id + " " + selection + " " + x);
		
		PreparedStatement statement= null;
		try {
			statement = con.prepareStatement(sql);
			
			if(selection == 1){
				statement.setString(1, (String) x);
			}
			else if(selection == 2){
				statement.setDouble(1, Double.parseDouble((String) x));
			}
			else if(selection == 3){
				statement.setDouble(1,  Double.parseDouble((String) x));
			}
			else if(selection == 4){
				statement.setInt(1, Integer.parseInt((String) x));
			}
			
			statement.setInt(2, id);
			
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Product updated successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteProduct(int id){
		String sql = "DELETE FROM Products WHERE pID=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Product deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * CUSTOMER CRUD
	*/
	public void insertCustomer(Customer a)
	{
		String sql = "INSERT INTO Customers (cID, firstName, lastName, addressLine1, addressLine2, City, postcode, contactTelephone) VALUES (seq_customer.nextval, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setString(1, (String)  a.getCustFirsName()); //First name
			statement.setString(2, (String) a.getCustLastName()); //Last name
			statement.setString(3, (String) a.getAddresLineOne()); //Address line 1
			statement.setString(4, (String) a.getAddresLineTwo()); //Address line 2
			statement.setString(5, (String) a.getCity()); //City
			statement.setString(6, (String) a.getPostCode()); // Post code
			statement.setString(7, (String) a.getPhoneNum()); //Telephone
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Customer inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void updateCustomer(int id, int selection, String x){
		
		String [] fields = {"firstName", "lastName", "addressLine1", "addressLine2", "City", "postcode", "contactTelephone"};
		
		String sql = "UPDATE Customers SET "+ fields[selection-1]+"=? WHERE cID=?";
		
		System.out.println(fields[selection-1]);
		
		PreparedStatement statement= null;
		try {
			statement = con.prepareStatement(sql);
						
			if(selection == 1){
				statement.setString(1, (String) x);
			}
			else if(selection == 2){
				statement.setString(1, (String) x);
			}
			else if(selection == 3){
				statement.setString(1, (String) x);
			}
			else if(selection == 4){
				statement.setString(1, (String) x);
			}
			else if(selection == 5){
				statement.setString(1, (String) x);
			}
			else if(selection == 6){
				statement.setString(1, (String) x);
			}
			else if(selection == 7){
				statement.setString(1, (String) x);
			}
			
			System.out.println("selection is:" + selection);
			
			statement.setInt(2, id);
			
			int rowsUpdated = statement.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("Product updated successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteCustomer(int id){
		String sql = "DELETE FROM Customers WHERE cID=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Customer deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * TRANSACTION CRUD
	*/	
	
	public void insertTransaction(Transaction a)
	{
		String sql = "INSERT INTO Transactions (tID, cID, totalValue) VALUES (seq_sales.nextval, ?, ?)";

		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(sql);
			
			statement.setInt(1, (int) a.getCustId()); //Product ID
			statement.setDouble(2, (double) a.getFinalPrice()); //Item Quantity
			
			int rowsInserted = statement.executeUpdate();
			
			if (rowsInserted > 0) {
				System.out.println("Transaction inserted successfully!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void deleteTransaction(int id){
		String sql = "DELETE FROM Transaction WHERE TransactionId=?";
		
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			int rowsDeleted = statement.executeUpdate();
			
			if (rowsDeleted > 0) 
				System.out.println("Transaction deleted successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * SELECT ALL METHOD FOR ALL TABLES
	*/
	public ResultSet select(String table)
	{
		String sql = "SELECT * FROM "+ table;
				
		Statement statement;
		ResultSet result= null;
		
		try {
			statement = con.createStatement();
			result = statement.executeQuery(sql);			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}

	public ResultSet selectProduct(int id)
	{
				
		String sql = "SELECT * FROM Products WHERE pID=?";
		
		PreparedStatement statement;
		ResultSet result= null;
		
		try {
			statement = con.prepareStatement(sql);
			statement.setInt(1, id);
			result = statement.executeQuery();			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}
	
	public ResultSet selectCustomer(ArrayList <String> a)
	{
		
		System.out.println("Array " + a.toString());
		String sql = "SELECT cID FROM Customers WHERE firstName=? and lastName=? and contactTelephone=?";
		
		PreparedStatement statement;
		ResultSet result= null;
		
		try {
			statement = con.prepareStatement(sql);
			statement.setString(1, a.get(0));
			statement.setString(2, a.get(1));
			statement.setString(3, a.get(6));
			result = statement.executeQuery();			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
	}
	
}
