package model;

import interfaces.IProduct;

public class Product implements IProduct{
	
	private int productId;
	private String productName;
	private double buyAtPrice;
	private double sellAtPrice;
	private int quantity;
	

	public Product()
	{
		
	}
	
	public Product(String a, double b, double c, int d)
	{
		productName = a;
		buyAtPrice = b;
		sellAtPrice = c;
		quantity = d;
	}
	
	public void setData(double buyAtPrice, double sellAtPrice, int quantity) {
		this.buyAtPrice = buyAtPrice;
		this.sellAtPrice = sellAtPrice;
		this.quantity = quantity;
	}
	
	public void setName(String prodName) {
		this.productName = prodName;
	}

	public void setBuyAt(double buyPrice) {
		this.buyAtPrice = buyPrice;
	}

	public void setSellAt(double sellPrice) {
		this.sellAtPrice = sellPrice;
	}
	
	public void setQuantity(int prodQuantity) {
		this.quantity = prodQuantity;
	}
	
	public void setProductId(int prodId) {
		this.productId = prodId;
	}

	public int getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public double getBuyPrice() {
		return buyAtPrice;
	}

	public double getSellPrice() {
		return sellAtPrice;
	}
	
	public int getQuantity() {
		return quantity;
	}

}
