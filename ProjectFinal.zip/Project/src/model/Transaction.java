package model;

public class Transaction {
	
	private Product product;
	private int itemQuantity;
	private int custID;
	
	public double getFinalPrice() {
		return finalPrice;
	}
	
	 public Transaction()
	{
		
	}

	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}

	private double finalPrice;
	
	public Transaction(Product product) {
		this.product = product;
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}
	
	public void setQantity(int quantity) {
		this.itemQuantity = quantity;
	}
	
	public void setCustomerId(int custID) {
		this.custID = custID;
	}
	
	public Product getProduct() {
		return product;
	}
	
	public int getQuantity() {
		return itemQuantity;
	}
	
	public int getCustId() {
		return custID;
	}
	
	
}
