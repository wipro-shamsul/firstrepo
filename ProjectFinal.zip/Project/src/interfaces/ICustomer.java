package interfaces;

public interface ICustomer {
	
	public void setCustFirstName(String name1);
	
	public void setCustLastName(String name2);
	
	public void setCustomerName(String name1, String name2);
	
	public void setCustAddLine1(String address1);
	
	public void setCustAddLine2(String address2);
	
	public void setCity(String city);
	
	public void setPostCode(String postCode);
	
	public void setCustomerAddress(String address1, String address2);
	
	public void setPhoneNumber(String phoneNum);
	
	public int getCustomerID();
	
	public String getCustFirsName();
	
	public String getCustLastName();
	
	public String getCustomerName();
	
	public String getAddresLineOne();
	
	public String getAddresLineTwo();
	
	public String getCity();
	
	public String getPostCode();
	
	public String getCustomerAddress();

	public String getPhoneNum();
}
