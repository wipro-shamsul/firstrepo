package controller;

import jdbc.DataIntegrator;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import model.Customer;
import model.Product;
import model.Transaction;

public class Controller {
	
	private HashMap<Integer,Transaction> transactions;
	private Customer customer;
	private Product product;
	private Transaction finalTransaction;
	DataIntegrator db;

	
	public Controller() {
		transactions = new HashMap<Integer,Transaction>();
		customer = new Customer();
		
		db = new DataIntegrator();
	}
	
	public void createNewUser(ArrayList<String> userData) {
		System.out.println("From controller " + userData.toString());
		
		db.connect();

		customer = new Customer(userData.get(0), userData.get(1),userData.get(2), userData.get(3), userData.get(4), userData.get(5), userData.get(6));
		
		db.insertCustomer(customer);
		db.close();
		System.out.println("The customer entry has successfully been created!");
	}
	
	public void modifyUserData(String userId, int dataColumn, String newValue) {
		//check whether the user exists in the database.
		db.connect();

		db.updateCustomer(Integer.parseInt(userId), dataColumn, newValue);
		db.close();
		
		if(dataColumn == 1) {
			System.out.println("Customer`s first name has been updated successfully");
		}
		else if(dataColumn == 2) {
			System.out.println("Customer`s last name has been updated successfully");
		}
		else if(dataColumn == 3) {
			System.out.println("Customer`s first line of address has been updated successfully");
		}
		else if(dataColumn == 4) {
			System.out.println("Customer`s second line of address has been updated successfully");
		}
		else if(dataColumn == 5) {
			System.out.println("Customer`s city has been updated successfully");
		}
		else if(dataColumn == 6) {
			System.out.println("Customer`s post code has been updated successfully");
		}
		else if(dataColumn == 7) {
			System.out.println("Customer`s phone number has been updated successfully");
		}

	}
	
	public void deleteCustomer(String userId) {
		//delete the customer from the database
		db.connect();
		db.deleteCustomer(Integer.parseInt(userId));
		db.close();
		System.out.println("You have successfuly deleted the customer");
	}
	
	public void createProduct(ArrayList<String> productData) {
		db.connect();
		
		product = new Product(productData.get(0), Double.parseDouble(productData.get(1)), Double.parseDouble(productData.get(2)), Integer.parseInt(productData.get(3)));

		db.insertProduct(product);
		db.close();
		System.out.println("The product entry has successfully been created!");
	}
	
	public <T> void modifyProduct(String prodId, int dataColumn, T newValue) {
		//make a call to the database to get the product and modify it based on the column entry and prodID.
		
		db.connect();
		db.updateProduct(Integer.parseInt(prodId), dataColumn, newValue);
		db.close();
		if(dataColumn == 1) {
			System.out.println("Product name has been updated successfully");
		}
		else if(dataColumn == 2) {
			System.out.println("Product buy at price has been updated successfully");
		}
		else if(dataColumn == 3) {
			System.out.println("Product sell at price has been updated successfully");
		}
		else if(dataColumn == 4) {
			System.out.println("Product quantity has been updated successfully");
		}
	}
	
	public void deleteProduct(String productId) {
		//delete product from the database.
		db.connect();
		db.deleteProduct(Integer.parseInt(productId));
		db.close();
		System.out.println("The product has been successfuly deleted!");
	}
	
	public void printProductData() {
		//get all the product data from the database!
	}
	
	public void addANewTransaction(String prodId, String quantity) throws SQLException {
		//get the product from the database based on prodID.
		
		db.connect();
		ResultSet s = db.selectProduct(Integer.parseInt(prodId));
		
		if(s.next())
		{
			s.getInt(1);
			s.getString(2);
			s.getDouble(3);
			s.getDouble(4);
			s.getInt(5);
		}
		
		Product prod = new Product(s.getString(2), s.getDouble(3), s.getDouble(4), s.getInt(5));
		prod.setProductId(Integer.parseInt(prodId));
		Transaction currTr = new Transaction(prod);

		if(!transactions.containsKey(Integer.parseInt(prodId))) {
			currTr.setQantity(Integer.parseInt(quantity));
			transactions.put(currTr.getProduct().getProductId(), currTr);
			System.out.println("The transaction has been added successfully");
		}
		else if(transactions.containsKey(Integer.parseInt(prodId))){
			transactions.get(Integer.parseInt(prodId)).setQantity(transactions.get(Integer.parseInt(prodId)).getQuantity() + Integer.parseInt(quantity));
			System.out.println("The transaction has been added successfully");
		}
		
	}
	
	public void modifyTransaction(String prodId, String newValue) {
		System.out.println("From Controller modified transaction with prodID:" + prodId + "; new value:" + newValue);
		if(transactions.isEmpty() == false) {
			if(transactions.containsKey(Integer.parseInt(prodId))) {
				transactions.get(Integer.parseInt(prodId)).setQantity(Integer.parseInt(newValue));
				System.out.println("The quantity of the transaction has been modified successfully");
			}
			else {
				System.out.println("There isn`t such a transaction!");
			}
			
		}
		else {
			System.out.println("Your transaction list is empty!");
		}
	}
	
	public void deleteTransaction(String prodId) {
		System.out.println("From controller deteled transaction is" + prodId);
		if(transactions.isEmpty() == false) {
			if(transactions.containsKey(Integer.parseInt(prodId))){
				transactions.remove(Integer.parseInt(prodId));
				System.out.println("The transaction has been deleted sucessfully");
			}
			else {
				System.out.println("There isn`t such a transaction!");
			}
		}
		else {
			System.out.println("Your transaction list is empty!");
		}
	}
	
	public void executeTransaction() {
		if(finalTransaction != null) {
			if(transactions.isEmpty() == false) {
				double finalSum = 0;
				for(Transaction transaction : transactions.values()) {
					finalSum += (transaction.getProduct().getSellPrice() * transaction.getQuantity());
				}
				finalTransaction.setFinalPrice(finalSum);
				//add the final transaction to the database!!!
				
				db.connect();
				db.insertTransaction(finalTransaction);
				db.close();
				
				System.out.println("The transaction is completed! The final sum is: " + finalSum);
			}
		}
		else {
			finalTransaction = new Transaction();
			if(transactions.isEmpty() == false) {
				double finalSum = 0;
				for(Transaction transaction: transactions.values()) {
					finalSum += (transaction.getProduct().getSellPrice() * transaction.getQuantity());
				}
				finalTransaction.setFinalPrice(finalSum);
				//add the final transaction to the database!!!
				
				db.connect();
				db.insertTransaction(finalTransaction);
				db.close();
				
				System.out.println("The transaction is completed! The final sum is: " + finalSum);
			}
		}
		finalTransaction = null;
		transactions.clear();
	}
	
	public void assignNewCustomerIDToTrans(ArrayList<String> userData) {
		//get cust Id from database
		db.connect();
		ResultSet rs = db.selectCustomer(userData);
		
		try {
			if(rs.next()){
				assignTranstoCustomer(rs.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.close();
		
	}
	
	public void assignTranstoCustomer(int custId) {
		finalTransaction = new Transaction();
		finalTransaction.setCustomerId(custId);
	}
}

